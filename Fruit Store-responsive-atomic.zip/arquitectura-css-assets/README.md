# arquitectura-css
This website was base in a desing in figma 

Prototype: https://www.figma.com/file/ZIZuMVCGh6cE3UQvTbFsuj/alura-bootstrap?node-id=0%3A1
